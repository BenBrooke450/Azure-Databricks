# Databricks notebook source
# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

race_results_20_19_df = spark.read.parquet(f"{presentaion_folder_path}/Best_Laps_2019_2020")

# COMMAND ----------

#This will create a temporary view of the DataFrame named "race_results_20_19_df" but if there is already a temp view with the same name as "race_results_20_19_df" it will throw an error
race_results_20_19_df.createTempView("race_results_20_19_df")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*)
# MAGIC FROM race_results_20_19_df
# MAGIC WHERE race_year = 2019

# COMMAND ----------

spark.sql("select * FROM race_results_20_19_df WHERE race_year = 2019").show()

# COMMAND ----------

#This will create or replace a temporary view of the DataFrame named "race_results_20_19_df"
race_results_20_19_df.createOrReplaceTempView("race_results_20_19_df")

# COMMAND ----------

#This will create or replace a global temporary view of the DataFrame named "race_results_20_19_df", meanin g it can be accessed from other sessions
race_results_20_19_df.createOrReplaceGlobalTempView("race_results_20_19_df")
