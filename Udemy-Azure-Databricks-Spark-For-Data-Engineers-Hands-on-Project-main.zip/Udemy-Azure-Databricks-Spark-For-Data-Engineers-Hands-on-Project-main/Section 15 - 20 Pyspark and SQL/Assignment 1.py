# Databricks notebook source
# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races").select(col("race_year"),col("name").alias("race_name"),col("date").alias("race_date"),col("circuit_id"),col("race_id"))

# COMMAND ----------

circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits").select(col("location").alias("circuit_location"),col("circuitit_id"))

# COMMAND ----------

races_circuits_df = races_df.join(circuits_df, races_df.circuit_id == circuits_df.circuitit_id)

# COMMAND ----------

driver_df = spark.read.parquet(f"{processed_folder_path}/drivers").select(col("name").alias("driver_name"),col("number").alias("driver_number"),col("nationality"),col("driver_id"))

# COMMAND ----------

results_df = spark.read.parquet(f"{processed_folder_path}/results").select(col("rank"),col("fastestLap"),col("time").alias("race_time"),col("points"),col("race_id"),col("constructor_id"),col("driver_id"))

# COMMAND ----------

constructors_df = spark.read.parquet(f"{processed_folder_path}/constructors").select(col("constructor_id"))

# COMMAND ----------

drivers_results = results_df.join(driver_df,results_df.driver_id == driver_df.driver_id, how="inner")

# COMMAND ----------

drivers_results_constructors = drivers_results.join(constructors_df, drivers_results.constructor_id == constructors_df.constructor_id, how="inner")

# COMMAND ----------

All_df = races_circuits_df.join(drivers_results_constructors, races_circuits_df.race_id == drivers_results_constructors.race_id, how="inner").dropDuplicates()

# COMMAND ----------

results_2020_Abu_df = All_df.filter((All_df.race_year == 2020) & (All_df.race_name == "Abu Dhabi Grand Prix")).orderBy(All_df.points.desc()).drop("constructor_id").drop("race_id").drop("driver_id").drop("circuitit_id")

# COMMAND ----------

results_2020_df = All_df.filter((All_df.race_year == 2020)).orderBy(All_df.points.desc()).drop("constructor_id").drop("race_id").drop("driver_id").drop("circuitit_id")

# COMMAND ----------

results_2020_df.write.mode("overwrite").parquet(f"{presentaion_folder_path}/Best_Laps_2020")

# COMMAND ----------

results_2020_2019_df = All_df.filter((All_df.race_year == 2020) | (All_df.race_year == 2019)).orderBy(All_df.points.desc()).drop("constructor_id").drop("race_id").drop("driver_id").drop("circuitit_id")

# COMMAND ----------

results_2020_2019_df.write.mode("overwrite").parquet(f"{presentaion_folder_path}/Best_Laps_2019_2020")

# COMMAND ----------

display(results_2020_df)

# COMMAND ----------

results_2020_Abu_df.write.mode("overwrite").parquet(f"{presentaion_folder_path}/Best_Laps_Abu_2020")

# COMMAND ----------

results_2020_2019_df .write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.race_results_2020_2019")
