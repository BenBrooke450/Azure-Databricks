-- Databricks notebook source
USE f1_processed;

-- COMMAND ----------

SELECT driver_name, COUNT(1) AS total_races,
      SUM(calculated_points) AS total_points,
      AVG(calculated_points) AS Average_points,
      race_year, team_name,
      RANK() OVER(ORDER BY AVG(calculated_points) DESC)
      FROM f1_presentation.calculated_points
      GROUP BY race_year, driver_name, team_name
      ORDER BY race_year, Average_points DESC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #After you have created your vizulisation you can then add it to the dashboard.
