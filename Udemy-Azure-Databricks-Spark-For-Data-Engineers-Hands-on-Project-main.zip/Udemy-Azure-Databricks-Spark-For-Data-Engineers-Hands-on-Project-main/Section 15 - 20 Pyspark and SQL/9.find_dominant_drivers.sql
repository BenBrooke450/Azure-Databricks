-- Databricks notebook source
SELECT driver_name, COUNT(1) AS total_races,
      SUM(calculated_points) AS total_points,
      AVG(calculated_points) AS Average_points FROM f1_presentation.calculated_points
      GROUP BY driver_name
      HAVING total_races > 50
      ORDER BY Average_points DESC
