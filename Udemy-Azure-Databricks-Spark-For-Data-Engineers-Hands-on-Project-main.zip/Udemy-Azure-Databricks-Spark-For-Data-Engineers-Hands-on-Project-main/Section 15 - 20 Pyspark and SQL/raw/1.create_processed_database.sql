-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_processed
LOCATION "/mnt/formula1dlben/processed"

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION "/mnt/formula1dlben/presentation"

-- COMMAND ----------

DROP TABLE IF EXISTS f1_processed.race_results_2020_2019
