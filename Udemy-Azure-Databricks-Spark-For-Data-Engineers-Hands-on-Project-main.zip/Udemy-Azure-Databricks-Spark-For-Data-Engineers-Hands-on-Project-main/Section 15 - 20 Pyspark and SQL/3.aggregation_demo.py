# Databricks notebook source
# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{presentaion_folder_path}/Best_Laps_2020")

# COMMAND ----------

display(race_results_df)

# COMMAND ----------

demo_df = race_results_df.filter(race_results_df.race_year == 2020)

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum, col

# COMMAND ----------

demo_df.select(count('*')).show()

# COMMAND ----------

demo_df.select(countDistinct("race_name")).show()

# COMMAND ----------

demo_df.filter(col("driver_name") == "Lewis Hamilton").select(race_results_df['driver_name'],race_results_df['points'],race_results_df['race_name']).show()

# COMMAND ----------

demo_df.groupBy("driver_name").sum("points").show()

# COMMAND ----------

demo_df.groupBy("driver_name").agg(sum("points").alias("total_points"),countDistinct("race_name")).show()

# COMMAND ----------

race_results_20_19_df = spark.read.parquet(f"{presentaion_folder_path}/Best_Laps_2019_2020")

# COMMAND ----------

from pyspark.sql.functions import desc, rank
from pyspark.sql.window import Window

# COMMAND ----------

demo_grouped_df = race_results_20_19_df.groupBy("driver_name","race_year").agg(sum("points").alias("total_points"),countDistinct("race_name")).show()

# COMMAND ----------

driverRankSpec = Window.partitionBy("race_year").orderBy("race_name","Rank","driver_name")

df = race_results_20_19_df.withColumn("Rank",rank().over(driverRankSpec))

display(df)
