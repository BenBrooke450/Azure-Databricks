-- Databricks notebook source
SHOW DATABASES

-- COMMAND ----------

USE f1_processed

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

SELECT * FROM f1_processed.drivers
  LIMIT 100

-- COMMAND ----------

SELECT * FROM f1_processed.drivers
  WHERE nationality = "British"

-- COMMAND ----------

SELECT * FROM f1_processed.drivers
  WHERE nationality = "British" AND dob > "1980-01-01"
  ORDER BY dob DESC

-- COMMAND ----------

SELECT * FROM f1_processed.drivers
  WHERE (nationality = "British" AND dob > "1980-01-01") OR (nationality = "Indian")
  ORDER BY dob DESC

-- COMMAND ----------

SELECT *, CONCAT(driver_ref, "-",code) AS name_and_ref FROM f1_processed.drivers

-- COMMAND ----------

SELECT *, CONCAT(driver_ref, "-",code) FROM f1_processed.drivers

-- COMMAND ----------

SELECT count(*) FROM f1_processed.drivers WHERE nationality = 'British'

-- COMMAND ----------

SELECT count(*), nationality FROM f1_processed.drivers GROUP BY nationality

-- COMMAND ----------

SELECT nationality, name, dob, RANK() OVER(PARTITION BY nationality ORDER BY dob) AS Rank  FROM f1_processed.drivers

-- COMMAND ----------


