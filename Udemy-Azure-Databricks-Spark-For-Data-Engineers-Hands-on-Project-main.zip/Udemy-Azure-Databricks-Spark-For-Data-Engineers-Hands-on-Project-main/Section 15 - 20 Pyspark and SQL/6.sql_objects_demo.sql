-- Databricks notebook source
SHOW DATABASES

-- COMMAND ----------

DESC DATABASE demo;

-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

-- MAGIC %run "../Section 14 Workflows/Configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_20_19_df = spark.read.parquet(f"{presentaion_folder_path}/race_results_2020_2019")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_20_19_df.write.format("parquet").mode("overwrite").saveAsTable("demo.Best_Laps_2019_2020")

-- COMMAND ----------

USE demo;

-- COMMAND ----------

DESC Best_Laps_2019_2020;

-- COMMAND ----------

SELECT *
  FROM demo.Best_Laps_2019_2020
  WHERE race_year = 2019;

-- COMMAND ----------

CREATE TABLE  race_results_2019_sql
AS
SELECT *
  FROM demo.Best_Laps_2019_2020
  WHERE race_year = 2019;

-- COMMAND ----------

DESC demo.race_results_2019_sql;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_20_19_df.write.format("parquet").option("path", f"{presentaion_folder_path}/Best_Laps_2019_2020_ext_py").mode("overwrite").saveAsTable("demo.Best_Laps_2019_2020_ext_py")

-- COMMAND ----------

SHOW TABLES IN demo

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW race_results_2019_sql
AS
SELECT *
  FROM demo.Best_Laps_2019_2020_ext_py

-- COMMAND ----------

SELECT * FROM race_results_2019_sql

-- COMMAND ----------

SHOW TABLES;
