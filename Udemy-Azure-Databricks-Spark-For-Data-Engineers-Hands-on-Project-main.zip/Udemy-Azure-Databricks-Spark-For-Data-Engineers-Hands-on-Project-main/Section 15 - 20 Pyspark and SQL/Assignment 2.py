# Databricks notebook source
# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

race_results_20_19_df = spark.read.parquet(f"{presentaion_folder_path}/Best_Laps_2019_2020")

# COMMAND ----------

display(race_results_20_19_df)

# COMMAND ----------

from pyspark.sql.functions import count, when, col, min

# COMMAND ----------

race_results_20_19_df.groupBy("nationality").agg(count("nationality")).show()

# COMMAND ----------

race_results_20_19_df.groupBy("nationality").agg(count(when(col("rank") == 1, "nationality")).alias("count_rank_1")).orderBy("count_rank_1", ascending=False).display()

# COMMAND ----------

race_results_20_19_df.groupBy("driver_name","race_name").agg(min("race_time").alias("Best_race_time")).orderBy("driver_name","race_name","Best_race_time").display()
