# Databricks notebook source
# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

races_df = spark.read.parquet("/mnt/formula1dlben/processed/races")

races_df = spark.read.parquet(f"{processed_folder_path}/races")
#/mnt/formula1dlben/processed

# COMMAND ----------

display(races_df)

# COMMAND ----------

races_filtered_df = races_df.filter((races_df.race_year == 2019) & (races_df["round"] <= 5))

#races_filtered_df = races_df.where((races_df.race_year == 2019) & (races_df["round"] <= 5))

# COMMAND ----------

display(races_filtered_df)

# COMMAND ----------

# Databricks notebook source
# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

races_df = spark.read.parquet("/mnt/formula1dlben/processed/races")

races_df = spark.read.parquet(f"{processed_folder_path}/races")
#/mnt/formula1dlben/processed

# COMMAND ----------

display(races_df)

# COMMAND ----------

races_filtered_df = races_df.filter((races_df.race_year == 2019) & (races_df["round"] <= 5))

#races_filtered_df = races_df.where((races_df.race_year == 2019) & (races_df["round"] <= 5))

# COMMAND ----------

display(races_filtered_df)

# COMMAND ----------
