# Databricks notebook source
raw_folder_path = "/mnt/formula1dlben/raw"
processed_folder_path = "/mnt/formula1dlben/processed"
presentaion_folder_path = "/mnt/formula1dlben/presentation"

# COMMAND ----------

#raw_folder_path = "abfss://raw@formula1ben.dfs.core.windows.net"

#processed_folder_path = "abfss://processed@formula1ben.dfs.core.windows.net"

#presentaion_folder_path = "abfss://presentation@formula1ben.dfs.core.windows.net"
