# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook Introduction
# MAGIC
# MAGIC ## Magic Command
# MAGIC - %python
# MAGIC - %sql
# MAGIC - %scala
# MAGIC - %md
# MAGIC

# COMMAND ----------

mytext = "Hello this is my text"

# COMMAND ----------

print(mytext)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT "HELLO"

# COMMAND ----------

# MAGIC %fs

# COMMAND ----------


