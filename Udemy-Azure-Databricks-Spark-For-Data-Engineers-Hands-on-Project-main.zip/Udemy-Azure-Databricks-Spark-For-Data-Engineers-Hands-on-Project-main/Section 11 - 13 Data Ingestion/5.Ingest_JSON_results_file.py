# Databricks notebook source
from pyspark.sql.types import StructType, StringType, IntegerType, StructField, FloatType

# COMMAND ----------

#This statement is to set the name of the widget. The second statement is to set the default value.
dbutils.widgets.text("p_file_date","2021-03-21")

#This statment is to make the wiget into a variable to be used within the notebook
p_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

result_schema = StructType(fields=[
    StructField("driverId", IntegerType(), True),
    StructField("resultId", IntegerType(), False),
    StructField("raceId", IntegerType(), True),
    StructField("constructorId", IntegerType(), True),
    StructField("number", IntegerType(), True),
    StructField("position",IntegerType(), True),
    StructField("positionText", StringType(), True),
    StructField("positionOrder", StringType(), True),
    StructField("points", FloatType(), True),
    StructField("laps", IntegerType(), True),
    StructField("time", StringType(), True),
    StructField("milliseconds", IntegerType(), True),
    StructField("fastestLap", IntegerType(), True),
    StructField("rank", IntegerType(), True),
    StructField("fastestLapTime", StringType(), True),
    StructField("fastestLapSpeed", FloatType(), True),
    StructField("statusId", IntegerType(), True)
    ])

# COMMAND ----------

df_result = spark.read.schema(result_schema).json(f"/mnt/formula1dlben/raw/{p_file_date}/results.json")

# COMMAND ----------

df_result.printSchema


# COMMAND ----------

display(df_result)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

results_with_columns_df = df_result.withColumnRenamed('positionText', 'position_Text').withColumnRenamed('positionOrder', 'position_Order').withColumnRenamed('driverId', 'driver_id').withColumnRenamed('resultId', 'result_id').withColumnRenamed('raceId', 'race_id').withColumnRenamed('constructorId', 'constructor_id').withColumnRenamed("fastestLapTime", "fastest_lap_time").withColumnRenamed("fastestLapSpeed", "fastest_lap_speed").withColumn("ingestion_date", current_timestamp())

# COMMAND ----------

display(results_with_columns_df)

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

results_final_df = results_with_columns_df.drop(col('statusId'))

# COMMAND ----------

results_final_df.write.mode("overwrite").parquet("/mnt/formula1dlben/processed/results")

# COMMAND ----------

spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

# COMMAND ----------

results_final_df = results_final_df.withColumn("points", col("points").cast("FLOAT"))

# COMMAND ----------

if (spark._jsparkSession.catalog().tableExists("f1_processed.results")):
    results_final_df.write.mode("overwrite").insertInto("f1_processed.results")
else:
    results_final_df.write.mode("overwrite").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.results")
