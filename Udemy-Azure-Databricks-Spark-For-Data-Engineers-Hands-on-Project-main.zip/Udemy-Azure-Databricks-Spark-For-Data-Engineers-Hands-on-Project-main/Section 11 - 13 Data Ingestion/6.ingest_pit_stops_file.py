# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

pit_schema = StructType(fields = [StructField("raceId", IntegerType(), False), StructField("driverId", IntegerType(), True), StructField("stop", StringType(), True),StructField("lap", IntegerType(), True), StructField("time", StringType(), True), StructField("milliseconds", IntegerType(), True), StructField("duration", IntegerType(), True)])

# COMMAND ----------

pit_stops_df = spark.read.schema(pit_schema).json("/mnt/formula1dlben/raw/pit_stops.json",multiLine=True)

# COMMAND ----------

display(pit_stops_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = pit_stops_df.withColumn('ingestion_date', current_timestamp()).withColumnRenamed('raceId', 'race_id').withColumnRenamed('driverId', 'driver_id')

# COMMAND ----------

final_df.write.mode('overwrite').parquet('/mnt/formula1dlben/processed/pit_stops')

# COMMAND ----------

final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.pit_stops")
