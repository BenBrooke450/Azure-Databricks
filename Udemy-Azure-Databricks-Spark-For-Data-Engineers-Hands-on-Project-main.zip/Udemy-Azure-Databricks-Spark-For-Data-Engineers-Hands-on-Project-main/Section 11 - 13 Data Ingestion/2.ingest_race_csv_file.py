# Databricks notebook source
#This statement is to set the name of the widget. The second statement is to set the default value.
dbutils.widgets.text("p_file_date","2021-03-21")

#This statment is to make the wiget into a variable to be used within the notebook
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

from pyspark.sql.types import IntegerType, DoubleType, StructType, StructField, StringType, DateType

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit, col, to_timestamp, concat

# COMMAND ----------

races_schema = StructType(fields = [StructField("raceId", IntegerType(), True),      StructField("year", IntegerType(), True),StructField("round", IntegerType(), True), StructField("circuitId", IntegerType(), True), StructField("name", StringType(), True), StructField("date", DateType(), True), StructField("time", StringType(), True), StructField("url", IntegerType(), True)])

# COMMAND ----------

df_races = spark.read.option("header", "true").schema(races_schema).csv(f"dbfs:/mnt/formula1dlben/raw/{v_file_date}/races.csv")

# COMMAND ----------

races_selected_df = df_races.select(col("raceId"), col("year"), col("round"), col("circuitId"), col("name"), col("date"), col("time"), col("url"))

# COMMAND ----------

renamed_races_df = races_selected_df.withColumnRenamed("raceId","race_id").withColumnRenamed("year", "race_year").withColumnRenamed("circuitId", "circuit_id")

# COMMAND ----------


new_column_df = renamed_races_df.withColumn("race_timestamp", to_timestamp(concat(col("date"),lit(" "),col("time")), "yyyy-MM-dd HH:mm:ss")).withColumn("Ingestion date", current_timestamp())

# COMMAND ----------

display(new_column_df)

# COMMAND ----------

new_column_df.write.mode("overwrite").parquet("/mnt/formula1dlben/processed/races")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/workshop/data/processed

# COMMAND ----------

new_column_df.write.mode("overwrite").partitionBy("race_year").parquet("/mnt/formula1dlben/processed/races")

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlben/processed/races"))

# COMMAND ----------

new_column_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.races")
