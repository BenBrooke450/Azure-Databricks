# Databricks notebook source
#This statement is to set the name of the widget. The second statement is to set the default value.
dbutils.widgets.text("p_file_date","2021-03-21")

#This statment is to make the wiget into a variable to be used within the notebook
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

constructor_schema = "constructorId INT, constructorRef STRING, name STRING, nationality STRING, url STRING"

# COMMAND ----------

constructor_df = spark.read.format("JSON").schema(constructor_schema).load(f"/mnt/formula1dlben/raw/{v_file_date}/constructors.json")

# COMMAND ----------

constructor_df.printSchema()

# COMMAND ----------

constructor_df_dropped = constructor_df.drop(constructor_df["url"])

# COMMAND ----------

display(constructor_df_dropped)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

constructor_final = constructor_df_dropped.withColumnRenamed("constructorId", "constructor_id").withColumnRenamed("constructorRef","constructor_ref").withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

constructor_final.write.mode("overwrite").parquet("/mnt/formula1dlben/processed/constructors")

# COMMAND ----------

constructor_final.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.constructors")
