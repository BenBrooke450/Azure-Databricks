# Databricks notebook source
#This statement is to set the name of the widget. The second statement is to set the default value.
dbutils.widgets.text("p_file_date","2021-03-21")

#This statment is to make the wiget into a variable to be used within the notebook
p_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

from pyspark.sql.types import StructType, StringType, IntegerType,DateType, StructField

# COMMAND ----------

name_schema = StructType(fields = [StructField("forename", StringType(), True), StructField("surname", StringType(), True)])

# COMMAND ----------

drivers_schema = StructType(fields = [StructField("driverId", IntegerType(), False),StructField("driverRef", StringType(), True),StructField("number", IntegerType(), True) ,StructField("name", name_schema, True), StructField("code", StringType(), True),StructField("dob", DateType(), True), StructField("nationality", StringType(), True)])

# COMMAND ----------

drivers_df = spark.read.format("JSON").schema(drivers_schema).load(f"/mnt/formula1dlben/raw/{p_file_date}/drivers.json")

# COMMAND ----------

drivers_df.printSchema()

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

from pyspark.sql.functions import col, current_timestamp, concat, lit

# COMMAND ----------

drivers_df = drivers_df.withColumnRenamed("driverRef", "driver_ref").withColumnRenamed("driverId", "driver_id").withColumn("ingestion_date", current_timestamp()).withColumn("name", concat(col("name.forename"), lit(" "), col("name.surname")))

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

drivers_df.write.mode("overwrite").parquet("/mnt/formula1dlben/processed/drivers")

# COMMAND ----------

drivers_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.drivers")
