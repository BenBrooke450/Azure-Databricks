# Databricks notebook source
v_resulst = dbutils.notebook.run("1.Ingest_circuits.csv_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("2.ingest_race_csv_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("3.Ingest_constructors_JSON_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("4.Ingest_drivers_json_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("5.Ingest_JSON_results_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("6.ingest_pit_stops_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("7.ingest_lap_times_folder",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_resulst = dbutils.notebook.run("8.ingest_qualifying_folder",0,{"p_data_source":"Ergast API"})
