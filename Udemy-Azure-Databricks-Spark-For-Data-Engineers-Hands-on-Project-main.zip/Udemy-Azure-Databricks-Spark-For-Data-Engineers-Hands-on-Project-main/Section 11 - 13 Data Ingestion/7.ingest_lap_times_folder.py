# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

lap_schema = StructType(fields = [StructField("raceId", IntegerType(), False), StructField("driverId", IntegerType(), True), StructField("lap", IntegerType(), True), StructField("time", StringType(), True), StructField("milliseconds", IntegerType(), True), StructField("position", IntegerType(), True)])

# COMMAND ----------

lap_time_df = spark.read.schema(lap_schema).csv("/mnt/formula1dlben/raw/lap_times")

# COMMAND ----------

display(lap_time_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = lap_time_df.withColumn('ingestion_date', current_timestamp()).withColumnRenamed('raceId', 'race_id').withColumnRenamed('driverId', 'driver_id')

# COMMAND ----------

final_df.write.mode('overwrite').parquet('/mnt/formula1dlben/processed/lap_times')

# COMMAND ----------

display(spark.read.parquet('/mnt/formula1dlben/processed/lap_times'))

# COMMAND ----------

final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.lap_times")
