# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingest circuits.csv file

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

#This statement is to set the name of the widget. The second statement is to set the default value.
dbutils.widgets.text("p_data_source","")

#This statment is to make the wiget into a variable to be used within the notebook
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

#This statement is to set the name of the widget. The second statement is to set the default value.
dbutils.widgets.text("p_file_date","2021-03-21")

#This statment is to make the wiget into a variable to be used within the notebook
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

v_file_date

# COMMAND ----------

v_data_source

# COMMAND ----------

#Within this folder I have created a configuration file that contains the paths to the raw and processed data.

# COMMAND ----------

# MAGIC %run "../Section 14 Workflows/Configuration"

# COMMAND ----------

# MAGIC %run "../Section 14 Workflows/Common_functions"

# COMMAND ----------

#We could now use this instead of using '/mnt/formula1ben/raw'
raw_folder_path

# COMMAND ----------

#Here use the spark.read.csv() function to read the raw data and we make the first row into headers
df_circuit = spark.read.csv(f"{raw_folder_path}/{v_file_date}/circuits.csv",header = True, inferSchema = True)

# COMMAND ----------

from pyspark.sql.types import IntegerType, DoubleType, StructType, StructField, StringType

# COMMAND ----------

circuits_schema = StructType(fields = [
    StructField("circuitId", IntegerType(), True),      
    StructField("circuitRef", StringType(), True),
    StructField("name", StringType(), True), 
    StructField("location", StringType(), True), 
    StructField("country", StringType(), True), 
    StructField("lat", DoubleType(), True), 
    StructField("lng", DoubleType(), True),
    StructField("alt", IntegerType(), True), 
    StructField("url", StringType(), True)])

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dlben/raw

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

type(df_circuit)

# COMMAND ----------

display(df_circuit)

# COMMAND ----------

df_circuit.printSchema()

# COMMAND ----------

df_circuit.describe().show()

# COMMAND ----------

display(df_circuit)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Select correct columns

# COMMAND ----------

circuits_selected_df = df_circuit.select('circuitId', 'circuitRef', 'name', 'location', 'country', 'lat', 'lng', 'alt')

# COMMAND ----------

display(circuits_selected_df)

# COMMAND ----------

circuits_selected_df = df_circuit.select(df_circuit.circuitId, df_circuit.circuitRef, df_circuit.name, df_circuit.location, df_circuit.country, df_circuit.lat, df_circuit.lng, df_circuit.alt)

# COMMAND ----------

display(circuits_selected_df)

# COMMAND ----------

circuits_selected_df = df_circuit.select(df_circuit["circuitId"], df_circuit["circuitRef"], df_circuit["name"], df_circuit["location"],df_circuit["country"], df_circuit["lat"], df_circuit["lng"], df_circuit["alt"])

# COMMAND ----------

display(circuits_selected_df)

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

circuits_selected_df = df_circuit.select(col("circuitId"), col("circuitRef"), col("name"), col("location"), col("country").alias("Race_Country"), col("lat"), col("lng"), col("alt"))

# COMMAND ----------

display(circuits_selected_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename Columns

# COMMAND ----------

circuits_renamed_df = circuits_selected_df.withColumnRenamed("circuitId","circuitit_id")\
    .withColumnRenamed("circuitRef","circuitref_id")\
        .withColumnRenamed("lat","latitude")\
            .withColumnRenamed("lng","longitude")\
                .withColumnRenamed("alt","altitude")

# COMMAND ----------

display(circuits_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Add ingestion date to the dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit, to_timestamp, concat

# COMMAND ----------

circuits_final_df = circuits_renamed_df.withColumn("ingestion_date", current_timestamp()) \
                                        .withColumn("env", lit("production"))

# COMMAND ----------


#Using the function above, add the ingestion_date column to the dataframe


circuits_final_df = add_ingestion_date(circuits_renamed_df)

# COMMAND ----------

display(circuits_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Write data to datalake as parquet

# COMMAND ----------

df = circuits_final_df.write.mode("overwrite").parquet("/mnt/formula1dlben/processed/circuits")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dlben/processed

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlben/processed/circuits"))

# COMMAND ----------

dbutils.notebook.exit("success")

# COMMAND ----------

circuits_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.circuits")
