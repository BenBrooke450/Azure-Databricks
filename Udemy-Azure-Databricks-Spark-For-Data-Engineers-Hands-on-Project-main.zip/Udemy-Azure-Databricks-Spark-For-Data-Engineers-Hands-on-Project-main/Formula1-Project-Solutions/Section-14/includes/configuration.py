# Databricks notebook source
raw_folder_path = "/mnt/formula1dl/raw"
processed_folder_path = "/mnt/formula1dl/processed"
presentation_folder_path = "/mnt/formula1dl/presentation"

# COMMAND ----------

#raw_folder_path = 'abfss://raw@formula1dl.dfs.core.windows.net'
#processed_folder_path = 'abfss://processed@formula1dl.dfs.core.windows.net'
#presentation_folder_path = 'abfss://presentation@formula1dl.dfs.core.windows.net'
