# Databricks notebook source
clientID = dbutils.secrets.get(scope="formula1-scope", key="client-ID")
tenantIDformula = dbutils.secrets.get(scope="formula1-scope", key="tenant-ID-formula")
Clientsecret = dbutils.secrets.get(scope="formula1-scope", key="Client-secret")

# COMMAND ----------

client_ID = clientID
tenant_ID = tenantIDformula
client_secret = Clientsecret

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlben.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1dlben.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1dlben.dfs.core.windows.net", client_ID)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1dlben.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1dlben.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_ID}/oauth2/token")

# COMMAND ----------

dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/"))

# COMMAND ----------

df = spark.read.csv("abfss://demo@formula1dlben.dfs.core.windows.net/circuits.csv")

# COMMAND ----------

display(df)
