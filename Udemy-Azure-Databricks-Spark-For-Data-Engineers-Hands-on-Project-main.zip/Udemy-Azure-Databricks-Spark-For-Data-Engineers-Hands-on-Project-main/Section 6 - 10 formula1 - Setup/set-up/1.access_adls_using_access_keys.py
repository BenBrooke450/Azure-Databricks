# Databricks notebook source
# MAGIC %md
# MAGIC

# COMMAND ----------

# 1. So originally below "formuladl_account_key" was simply a code pointing to your storage account - Microsoft.Storage/storageAccounts/formula1dlben/keys

# 2. As this is unsafe, we are using the following to get the key from Azure Key Vault - /secrets/formula1dl-account-key

# 3. This prevents us from having to hard code the key in our code and prevents us from having to re-deploy our code if the key changes and keeps it from appearing within a repository.

formuladl_account_key = dbutils.secrets.get(scope="formula1-scope", key="formula1dl-account-key")

# COMMAND ----------

#We have now configured out access.
spark.conf.set("fs.azure.account.key.formula1dlben.dfs.core.windows.net", formuladl_account_key)

# COMMAND ----------

#Now we can access our data within our storage container in Azure
dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/"))

# COMMAND ----------

df = spark.read.csv("abfss://demo@formula1dlben.dfs.core.windows.net/circuits.csv")

# COMMAND ----------

display(df)
