# Databricks notebook source
def mount_adls(storage_account_name, container_name):

    #Get the credentials from the secrets
    clientID = dbutils.secrets.get(scope="formula1-scope", key="client-ID")
    tenantIDformula = dbutils.secrets.get(scope="formula1-scope", key="tenant-ID-formula")
    Clientsecret = dbutils.secrets.get(scope="formula1-scope", key="Client-secret")

    #Verify access to the storage container
    configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": clientID,
          "fs.azure.account.oauth2.client.secret": Clientsecret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenantIDformula}/oauth2/token"}
    
    #Check if the mount point exists
    if any(mount.mountPoint == f"/mnt/{storage_account_name}/{container_name}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storage_account_name}/{container_name}")
    
    #We can now mount the storage
    dbutils.fs.mount(
    source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
    mount_point = f"/mnt/{storage_account_name}/{container_name}",
    extra_configs = configs)

    display(dbutils.fs.mounts())



# COMMAND ----------

mount_adls("formula1dlben","raw")

# COMMAND ----------

mount_adls("formula1dlben","processed")

# COMMAND ----------

mount_adls("formula1dlben","presentation")

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

"""
clientID = dbutils.secrets.get(scope="formula1-scope", key="client-ID")
tenantIDformula = dbutils.secrets.get(scope="formula1-scope", key="tenant-ID-formula")
Clientsecret = dbutils.secrets.get(scope="formula1-scope", key="Client-secret")

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": clientID,
          "fs.azure.account.oauth2.client.secret": Clientsecret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenantIDformula}/oauth2/token"}


dbutils.fs.mount(
  source = "abfss://demo@formula1dlben.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlben/demo",
  extra_configs = configs)
"""


# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlben/demo"))

# COMMAND ----------

df = spark.read.csv("/mnt/formula1dlben/demo/circuits.csv")

# COMMAND ----------

display(df)

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

#dbutils.fs.unmount('/mnt/formula1dlben/demo')
