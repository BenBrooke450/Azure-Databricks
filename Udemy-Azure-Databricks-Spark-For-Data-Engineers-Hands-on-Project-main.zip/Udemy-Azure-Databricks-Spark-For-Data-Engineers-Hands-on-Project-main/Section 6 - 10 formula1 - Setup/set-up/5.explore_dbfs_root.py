# Databricks notebook source
#Here we are looking at all the files available
display(dbutils.fs.ls("/"))

# COMMAND ----------

#If we look futher we can see the FileStore
display(dbutils.fs.ls("/FileStore"))

# COMMAND ----------


