# Databricks notebook source
# MAGIC %md
# MAGIC > A shared access signature (SAS) provides secure delegated access to resources in your storage account. With a SAS, you have granular control over how a client can access your data. For example:
# MAGIC
# MAGIC - What resources the client may access.
# MAGIC - What permissions they have to those resources.
# MAGIC - How long the SAS is valid.
# MAGIC
# MAGIC https://learn.microsoft.com/en-us/azure/storage/common/storage-sas-overview

# COMMAND ----------

# 1. So originally below "formuladl_SAS_Key" was simply a code pointing to one of our containers within our storage account.

# 2. As this is unsafe, we are using the following to get the key from Azure Key Vault - /secrets/Formula1-demo-SAS-Token

# 3. This prevents us from having to hard code the key in our code and prevents us from having to re-deploy our code if the key changes and keeps it from appearing within a repository.


formuladl_SAS_Key = dbutils.secrets.get(scope="formula1-scope", key="Formula1-demo-SAS-Token")

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlben.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1dlben.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1dlben.dfs.core.windows.net", formuladl_SAS_Key)

# COMMAND ----------

dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/"))

# COMMAND ----------

df = spark.read.csv("abfss://demo@formula1dlben.dfs.core.windows.net/circuits.csv")

# COMMAND ----------

display(df)
