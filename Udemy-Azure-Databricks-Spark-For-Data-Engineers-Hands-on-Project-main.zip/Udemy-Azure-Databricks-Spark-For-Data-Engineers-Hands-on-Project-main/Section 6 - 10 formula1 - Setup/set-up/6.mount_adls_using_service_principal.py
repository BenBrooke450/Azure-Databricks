# Databricks notebook source
# MAGIC %md
# MAGIC

# COMMAND ----------

clientID = dbutils.secrets.get(scope="formula1-scope", key="client-ID")
tenantIDformula = dbutils.secrets.get(scope="formula1-scope", key="tenant-ID-formula")
Clientsecret = dbutils.secrets.get(scope="formula1-scope", key="Client-secret")

# COMMAND ----------

client_ID = clientID
tenant_ID = tenantIDformula
client_secret = Clientsecret

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_ID,
          "fs.azure.account.oauth2.client.secret": client_secret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_ID}/oauth2/token"}



# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://demo@formula1dlben.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlben/demo",
  extra_configs = configs)

# COMMAND ----------

#The command dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/") no longer works because the storage account has been mounted to a specific mount point in the Databricks File System (DBFS). Once the storage is mounted, you should use the mount point path to interact with the files.

#LOOK AT THE ABOVE FILE, "mount_point = /mnt/formula1dlben/demo" sp the file we are looking for no longer exsists

dbutils.fs.ls("abfss://demo@formula1dlben.dfs.core.windows.net/")

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlben/demo"))

# COMMAND ----------

df = spark.read.csv("/mnt/formula1dlben/demo/circuits.csv")

# COMMAND ----------

display(df)

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

#dbutils.fs.unmount('/mnt/formula1dlben/demo')
