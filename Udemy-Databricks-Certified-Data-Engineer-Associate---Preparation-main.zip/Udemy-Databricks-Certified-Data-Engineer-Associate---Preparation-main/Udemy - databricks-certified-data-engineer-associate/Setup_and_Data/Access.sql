-- Databricks notebook source
SELECT * FROM hive_metastore.f1_processed.results
