# Databricks notebook source
full_name = "Derar Alhussein"
